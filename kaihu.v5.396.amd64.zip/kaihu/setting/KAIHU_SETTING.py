#设置服务器IP地址
SERVER_IP = '192.168.0.1'
#设置是否打开邮箱提示
EMAIL_NOTICE = False
#如果打开邮箱提示，设置邮箱地址
FORM_EMAIL_ADDRESS = ''
#如果打开邮箱提示，设置邮箱密码
FORM_EMAIL_PASSWORD = ''
#如果打开邮箱提示，设置邮箱SMTP服务器地址
FORM_EMAIL_SMTP_SERVER = ''
